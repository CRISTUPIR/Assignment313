public class Example {
    public static void main(String[] args) {
        int[] nums = {1, 2, 3, 4, 5};
        int sum = sumArray(nums);
        double avg = calculateAverage(nums);
        System.out.println("Sum: " + sum);
        System.out.println("Average: " + avg);
    }

    public static int sumArray(int[] nums) {
        int sum = 0;
        for (int i = 0; i < nums.length; i++) {
            sum += nums[i];
        }
        return sum;
    }

    public static double calculateAverage(int[] nums) {
        double sum = sumArray(nums);
        double avg = sum / nums.length;
        return avg;
    }
}
